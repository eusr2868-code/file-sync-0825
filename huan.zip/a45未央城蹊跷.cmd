@echo off
chcp 65001 > nul
xcopy "%cd%\bao\WYC\*.txt" "%cd%\1\蹊跷配置\" /y /h /i
exit