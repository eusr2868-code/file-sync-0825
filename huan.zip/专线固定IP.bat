@echo off
chcp 65001 >nul
::最小化后台执行，不弹出黑窗口
if "%1"=="hide" goto run
start /min "" "%~f0" hide
exit

:run
::断开旧连接，完全屏蔽输出
rasdial "AutoADSL" /disconnect >nul 2>&1
::静默拨号，不显示任何过程窗口
rasdial "AutoADSL" 888 888 >nul 2>&1
exit