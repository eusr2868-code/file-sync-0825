@echo off
chcp 65001 > nul
xcopy "%cd%\bao\JNJB3\*.txt" "%cd%\1\蹊跷配置\" /y /h /i
exit