@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "UPDATE_ROOT=%TEMP%\YYS-Agent-Universal-Updater"
set "UPDATE_ZIP=%TEMP%\YYS-Agent-Universal-Updater.zip"
set "DOWNLOAD_OK=0"

if exist "%UPDATE_ROOT%" rmdir /s /q "%UPDATE_ROOT%"
del /q "%UPDATE_ZIP%" 2>nul
mkdir "%UPDATE_ROOT%" >nul 2>&1

echo Downloading the current YYS-Agent updater...
for %%U in (
    "https://ghfast.top/https://raw.githubusercontent.com/eusr2868-code/file-sync-0825/main/latest-updater.zip"
    "https://gh-proxy.com/https://raw.githubusercontent.com/eusr2868-code/file-sync-0825/main/latest-updater.zip"
    "https://ghproxy.net/https://raw.githubusercontent.com/eusr2868-code/file-sync-0825/main/latest-updater.zip"
    "https://cdn.jsdelivr.net/gh/eusr2868-code/file-sync-0825@main/latest-updater.zip"
    "https://raw.githubusercontent.com/eusr2868-code/file-sync-0825/main/latest-updater.zip"
) do (
    if "!DOWNLOAD_OK!"=="0" (
        echo Trying %%~U
        del /q "%UPDATE_ZIP%" 2>nul
        curl.exe --fail --location --connect-timeout 8 --max-time 45 --user-agent "YYS-Agent-Universal-Updater/1.3" --output "%UPDATE_ZIP%" "%%~U"
        if not errorlevel 1 if exist "%UPDATE_ZIP%" (
            for %%F in ("%UPDATE_ZIP%") do if %%~zF GTR 1000 set "DOWNLOAD_OK=1"
        )
    )
)
if "!DOWNLOAD_OK!"=="0" goto :download_failed

echo Extracting the updater...
where tar.exe >nul 2>&1
if not errorlevel 1 tar.exe -xf "%UPDATE_ZIP%" -C "%UPDATE_ROOT%"
if not exist "%UPDATE_ROOT%\update.cmd" powershell.exe -NoLogo -NoProfile -Command "Expand-Archive -LiteralPath '%UPDATE_ZIP%' -DestinationPath '%UPDATE_ROOT%' -Force"
if not exist "%UPDATE_ROOT%\update.cmd" goto :extract_failed

echo Starting the current updater...
call "%UPDATE_ROOT%\update.cmd"
set "EXITCODE=%ERRORLEVEL%"
if not "%EXITCODE%"=="0" pause
exit /b %EXITCODE%

:download_failed
echo Could not download the current updater from any channel.
pause
exit /b 1

:extract_failed
echo Could not extract the current updater.
pause
exit /b 1