@echo off
setlocal
powershell.exe -NoLogo -NoProfile -File "%~dp0update.ps1"
set "EXITCODE=%ERRORLEVEL%"
if not "%EXITCODE%"=="0" (
    echo Update failed. Exit code: %EXITCODE%
    pause
)
exit /b %EXITCODE%
