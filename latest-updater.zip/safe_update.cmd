@echo off
setlocal EnableExtensions
set "UPDATE_ROOT=%~dp0"
set "UPDATE_PS1=%UPDATE_ROOT%update.ps1"

rem Run the downloaded updater with a process-scoped policy override.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%UPDATE_PS1%"
set "EXITCODE=%ERRORLEVEL%"
if not "%EXITCODE%"=="0" (
    echo Update failed. Exit code: %EXITCODE%
    pause
)
exit /b %EXITCODE%
