﻿$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$desktop = [Environment]::GetFolderPath('Desktop')
if ([string]::IsNullOrWhiteSpace($desktop)) { throw 'Desktop folder could not be resolved.' }
$destination = Join-Path $desktop ([string]([char]0x5305))
$tempZip = Join-Path ([IO.Path]::GetTempPath()) 'yys-agent-update.zip'
$expectedSha256 = 'd4cc58c8103bf039c783792d2daf6af99ec2451cd2f27bc85bc723014641c301'
$urls = @(
    "https://testingcf.jsdelivr.net/gh/eusr2868-code/file-sync-0825@53df4ade4a6b8d033d5b2494a454c5c3c2b96b90/huan.zip",
    "https://cdn.jsdmirror.com/gh/eusr2868-code/file-sync-0825@53df4ade4a6b8d033d5b2494a454c5c3c2b96b90/huan.zip",
    "https://fastly.jsdelivr.net/gh/eusr2868-code/file-sync-0825@53df4ade4a6b8d033d5b2494a454c5c3c2b96b90/huan.zip",
    "https://testingcf.jsdelivr.net/gh/eusr2868-code/file-sync-0825@main/huan.zip",
    "https://cdn.jsdmirror.com/gh/eusr2868-code/file-sync-0825@main/huan.zip",
    "https://fastly.jsdelivr.net/gh/eusr2868-code/file-sync-0825@main/huan.zip",
    "https://testingcf.jsdelivr.net/gh/eusr2868-code/file-sync-0825@main/huan.zip",
    "https://cdn.jsdmirror.com/gh/eusr2868-code/file-sync-0825@main/huan.zip",
    'https://cdn.jsdelivr.net/gh/eusr2868-code/file-sync-0825@main/huan.zip',
    'https://github.com/eusr2868-code/file-sync-0825/raw/main/huan.zip',
    'https://cdn.jsdelivr.net/gh/eusr2868-code/file-sync-0825@main/huan.zip',
    'https://raw.githubusercontent.com/eusr2868-code/file-sync-0825/main/huan.zip'
)

Write-Host 'YYS-Agent update started.'
Write-Host ('Destination: ' + $destination)
$downloaded = $false
foreach ($url in $urls) {
    try {
        Write-Host ('Downloading: ' + $url)
        Remove-Item -LiteralPath $tempZip -Force -ErrorAction SilentlyContinue
        & curl.exe --ssl-no-revoke --fail --location --connect-timeout 8 --max-time 45 --retry 1 --retry-delay 1 --user-agent 'YYS-Agent-Updater/1.3' --output $tempZip $url
        if ($LASTEXITCODE -ne 0) { continue }
        if ((Get-Item -LiteralPath $tempZip).Length -le 1000) { continue }
        $actual = (Get-FileHash -LiteralPath $tempZip -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actual -eq $expectedSha256) { $downloaded = $true; break }
        Write-Host 'Downloaded package checksum did not match; trying next channel.'
    } catch {
        Write-Host ('Download failed: ' + $_.Exception.Message)
    }
}
if (-not $downloaded) { throw 'No valid update package was downloaded.' }

$oldSt = Join-Path $destination 'bao\ST'
if (Test-Path -LiteralPath $oldSt) { Remove-Item -LiteralPath $oldSt -Recurse -Force }
New-Item -ItemType Directory -Force -Path $destination | Out-Null
Expand-Archive -LiteralPath $tempZip -DestinationPath $destination -Force
$deleteItems = @('8双图补漏.cmd')
foreach ($relativePath in $deleteItems) {
    $deletePath = Join-Path $destination $relativePath
    if (Test-Path -LiteralPath $deletePath) {
        Remove-Item -LiteralPath $deletePath -Force
        Write-Host ('Deleted: ' + $relativePath)
    } else {
        Write-Host ('Delete skipped (not found): ' + $relativePath)
    }
}
Remove-Item -LiteralPath $tempZip -Force -ErrorAction SilentlyContinue
Write-Host 'YYS-Agent update completed.'
exit 0
