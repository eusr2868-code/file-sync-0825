﻿param([string]$DestinationOverride)
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$desktop = [Environment]::GetFolderPath('Desktop')
if (-not $DestinationOverride -and [string]::IsNullOrWhiteSpace($desktop)) {
    throw 'Desktop folder could not be resolved.'
}
$destination = if ($DestinationOverride) { $DestinationOverride } else { Join-Path $desktop ([string]([char]0x5305)) }
$work = Join-Path ([IO.Path]::GetTempPath()) ([string]('yys-agent-' + [guid]::NewGuid().ToString('N')))
$expectedSha256 = 'a829dce95a75a29690a3eeec0076d7d56cbaadd8892b41fc6fe6186f95164c6f'
$commit = 'e7ea2541642a91db131dd30623977a6594cf24a2'
$mirrors = @('cdn.jsdelivr.net', 'fastly.jsdelivr.net', 'testingcf.jsdelivr.net', 'cdn.jsdmirror.com')
$parts = @(
    @{ Name = 'huan.part1.zip'; Size = 14680064; Hash = 'eba6b8332f9da641d21d855fa06d237c15fec878817ac5ca82816c5a5b42ec8d' },
    @{ Name = 'huan.part2.zip'; Size = 14680064; Hash = '64118a6f7c6d0cf1ffe8cd2389ba754ea654cdbcee63daacc09a0082111b39a5' },
    @{ Name = 'huan.part3.zip'; Size = 11221941; Hash = '029b2cc53ed663e17f9bbd3496ec0919657c03c9be48160a773cc9f8a5fa9581' }
)

Write-Host 'YYS-Agent update started.'
Write-Host ('Destination: ' + $destination)
New-Item -ItemType Directory -Path $work -Force | Out-Null
$jobs = @()
try {
    foreach ($part in $parts) {
        $jobs += Start-Job -ArgumentList $part.Name, $part.Size, $part.Hash, $work, $commit, $mirrors -ScriptBlock {
            param($name, $size, $hash, $dir, $revision, $hosts)
            # curl writes mirror failures to stderr; with ErrorActionPreference Stop
            # PowerShell 5.1 turns that into a terminating NativeCommandError and the
            # whole job dies before the next mirror is tried.
            $ErrorActionPreference = 'Continue'
            $file = Join-Path $dir $name
            foreach ($hostName in $hosts) {
                $url = "https://$hostName/gh/eusr2868-code/file-sync-0825@$revision/$name"
                Remove-Item -LiteralPath $file -Force -ErrorAction SilentlyContinue
                try {
                    & curl.exe --ssl-no-revoke --fail --location --connect-timeout 8 --max-time 90 --silent --show-error --user-agent 'YYS-Agent-Updater/2.0' --output $file $url 2>$null
                } catch {
                }
                $exit = $LASTEXITCODE
                if ($exit -eq 0 -and (Test-Path -LiteralPath $file)) {
                    $item = Get-Item -LiteralPath $file
                    if ($item.Length -eq $size -and (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLowerInvariant() -eq $hash) {
                        return [pscustomobject]@{ Name = $name; Ok = $true; Channel = $hostName }
                    }
                }
            }
            return [pscustomobject]@{ Name = $name; Ok = $false; Channel = 'all channels failed' }
        }
    }
    Write-Host 'Downloading 3 verified parts in parallel...'
    $null = $jobs | Wait-Job -Timeout 400
    foreach ($job in $jobs) {
        if ($job.State -ne 'Completed') { throw ('Download timed out: ' + $job.Name) }
        $result = $job | Receive-Job
        if (-not $result.Ok) { throw ('Download failed: ' + ($result | Out-String)) }
        Write-Host ('Verified ' + $result.Name + ' via ' + $result.Channel)
    }

    $tempZip = Join-Path $work 'huan.zip'
    $output = [IO.File]::Create($tempZip)
    try {
        foreach ($part in $parts) {
            $inputFile = [IO.File]::OpenRead((Join-Path $work $part.Name))
            try { $inputFile.CopyTo($output) } finally { $inputFile.Dispose() }
        }
    } finally { $output.Dispose() }
    $actual = (Get-FileHash -LiteralPath $tempZip -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actual -ne $expectedSha256) { throw 'Merged package checksum did not match.' }
    Write-Host 'Merged ZIP checksum verified.'

    $oldSt = Join-Path $destination 'bao\ST'
    if (Test-Path -LiteralPath $oldSt) { Remove-Item -LiteralPath $oldSt -Recurse -Force }
    New-Item -ItemType Directory -Force -Path $destination | Out-Null
    Expand-Archive -LiteralPath $tempZip -DestinationPath $destination -Force
    $deleteItems = @('8双图补漏.cmd')
    foreach ($relativePath in $deleteItems) {
        $deletePath = Join-Path $destination $relativePath
        if (Test-Path -LiteralPath $deletePath) {
            Remove-Item -LiteralPath $deletePath -Force
            Write-Host ('Deleted: ' + $relativePath)
        }
    }
    Write-Host 'YYS-Agent update completed.'
} finally {
    foreach ($job in $jobs) {
        if ($job.State -eq 'Running') { $job | Stop-Job }
        $job | Remove-Job -Force -ErrorAction SilentlyContinue
    }
    Remove-Item -LiteralPath $work -Recurse -Force -ErrorAction SilentlyContinue
}
