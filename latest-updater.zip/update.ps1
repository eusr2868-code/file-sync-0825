$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$desktop = [Environment]::GetFolderPath('Desktop')
if ([string]::IsNullOrWhiteSpace($desktop)) { throw 'Desktop folder could not be resolved.' }
$destination = Join-Path $desktop '包'
$tempZip = Join-Path ([IO.Path]::GetTempPath()) 'yys-agent-update.zip'
$urls = @(
    'https://cdn.jsdelivr.net/gh/eusr2868-code/file-sync-0825@52cd4190d7629cda5455f339054b4b8eb959b572/huan.zip',
    'https://raw.githubusercontent.com/eusr2868-code/file-sync-0825/main/huan.zip',
    'https://github.com/eusr2868-code/file-sync-0825/releases/latest/download/huan.zip',
    'https://gh-proxy.com/https://raw.githubusercontent.com/eusr2868-code/file-sync-0825/main/huan.zip'
)

Write-Host 'YYS-Agent update started.'
Write-Host ('Destination: ' + $destination)
$downloaded = $false
foreach ($url in $urls) {
    try {
        Write-Host ('Downloading: ' + $url)
        Remove-Item -LiteralPath $tempZip -Force -ErrorAction SilentlyContinue
        & curl.exe --fail --location --connect-timeout 8 --max-time 45 --user-agent 'YYS-Agent-Updater/1.0' --output $tempZip $url
        if ($LASTEXITCODE -eq 0 -and (Get-Item -LiteralPath $tempZip).Length -gt 1000) {
            $downloaded = $true
            break
        }
    } catch {
        Write-Host ('Download failed: ' + $_.Exception.Message)
    }
}
if (-not $downloaded) { throw 'All download channels failed.' }

$oldSt = Join-Path $destination 'bao\ST'
if (Test-Path -LiteralPath $oldSt) {
    Write-Host 'Removing old bao\ST.'
    Remove-Item -LiteralPath $oldSt -Recurse -Force
}

New-Item -ItemType Directory -Force -Path $destination | Out-Null
Write-Host 'Extracting package.'
Expand-Archive -LiteralPath $tempZip -DestinationPath $destination -Force
Remove-Item -LiteralPath $tempZip -Force -ErrorAction SilentlyContinue
Write-Host 'YYS-Agent update completed.'
exit 0
