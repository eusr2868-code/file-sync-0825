﻿$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$desktop = [Environment]::GetFolderPath('Desktop')
if ([string]::IsNullOrWhiteSpace($desktop)) { throw 'Desktop folder could not be resolved.' }
$destination = Join-Path $desktop ([string]([char]0x5305))
$tempZip = Join-Path ([IO.Path]::GetTempPath()) 'yys-agent-update.zip'
$expectedSha256 = '0736f55035bbb592fd3a5fe0bc748a535d7097b77fec6fbd87ce397e1759e7de'
$urls = @(
    'https://gh-proxy.com/https://raw.githubusercontent.com/eusr2868-code/file-sync-0825/main/huan.zip',
    'https://github.com/eusr2868-code/file-sync-0825/raw/main/huan.zip',
    'https://cdn.jsdelivr.net/gh/eusr2868-code/file-sync-0825@52cd4190d7629cda5455f339054b4b8eb959b572/huan.zip',
    'https://raw.githubusercontent.com/eusr2868-code/file-sync-0825/main/huan.zip'
)

Write-Host 'YYS-Agent update started.'
Write-Host ('Destination: ' + $destination)
$downloaded = $false
foreach ($url in $urls) {
    try {
        Write-Host ('Downloading: ' + $url)
        Remove-Item -LiteralPath $tempZip -Force -ErrorAction SilentlyContinue
        & curl.exe --fail --location --connect-timeout 8 --max-time 45 --user-agent 'YYS-Agent-Updater/1.2' --output $tempZip $url
        if ($LASTEXITCODE -ne 0) { continue }
        if ((Get-Item -LiteralPath $tempZip).Length -le 1000) { continue }
        $actual = (Get-FileHash -LiteralPath $tempZip -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actual -eq $expectedSha256) { $downloaded = $true; break }
        Write-Host 'Downloaded package checksum did not match; trying next channel.'
    } catch {
        Write-Host ('Download failed: ' + $_.Exception.Message)
    }
}
if (-not $downloaded) { throw 'No valid update package was downloaded.' }

$oldSt = Join-Path $destination 'bao\ST'
if (Test-Path -LiteralPath $oldSt) { Remove-Item -LiteralPath $oldSt -Recurse -Force }
New-Item -ItemType Directory -Force -Path $destination | Out-Null
Expand-Archive -LiteralPath $tempZip -DestinationPath $destination -Force
Remove-Item -LiteralPath $tempZip -Force -ErrorAction SilentlyContinue
Write-Host 'YYS-Agent update completed.'
exit 0
